import React,{useState}from 'react';
import { Text, View, StyleSheet, FlatList, Image} from 'react-native';
import AppLoading from 'expo-app-loading';
import {useFonts, Inter_900Black, Allan_400Regular,Oswald_300Light, Bangers_400Regular, Jost_600SemiBold_Italic} from '@expo-google-fonts/dev';

export default function App() {

let [fontsLoaded] =useFonts({
Inter_900Black,
Allan_400Regular,
Oswald_300Light, 
Bangers_400Regular,
Jost_600SemiBold_Italic
});

if(!fontsLoaded){
  return <AppLoading/>;
}else{
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>
      5 séries que eu (João) recomendo
      {'\n'}{'\n'}
      </Text>
      <FlatList //Laço de repetição - loop
        data={arrayConsole}
        renderItem={({item})=>(
      <View>
        <Text style={console}>
         {'\n'}
        <Text style={styles.subtitulo2}>{item.titulo}</Text>
        {'\n'}
        {'\n'}
        <Text style={styles.subtitulo}> Lançamento:</Text>
        <Text style={styles.informacoes}>{item.lancamento}</Text> 
        {'\n'} 
        <Text style={styles.subtitulo}> Descrição:</Text>
        <Text style={styles.informacoes}>{item.descricao}</Text>
        {'\n'}
        {'\n'}
        </Text>
        <Image style={styles.img} source={item.capa}/>
      </View>
      )}
      />
    </View>
  );
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#696969',
    padding: 8,
    alignItems:'center',
    marginTop: 20
  },
  titulo: {
    fontSize: 40,
    fontFamily:'Jost_600SemiBold_Italic',
    marginTop: 10,
    textAlign: 'center'
  },
  img: {
    borderRadius:10,
    width: 300,
    height: 200, 
    resizeMode: 'center'
  }, 
  subtitulo:{
    fontSize: 20,
    color: '#66a7fe',
    fontWeight: 100,
    fontFamily: 'Allan_400Regular'
  },
  informacoes:{
        fontSize: 15,
    fontWeight: 100,
    fontFamily: 'Oswald_300Light'
  },
  subtitulo2:{
    fontSize: 30,
    color: 'black',
    fontWeight: 100,
    fontFamily: 'Bangers_400Regular',
    textAlign: 'center',
  }
});

const arrayConsole =[
  {titulo:'Peaky Blinders', lancamento:' 2013', descricao:' Os Peaky Blinders são uma organização criminosa de origem cigana que se passa na cidade de Birmingham em 1919, formada após o final da Primeira Guerra Mundial. A história é centrada na ambição do líder da gangue inglesa, Thomas Shelby.',
capa:require('./assets/pb.jpg')},
  {titulo:'Breaking Bad',lancamento:' 2008', descricao:' O professor de química Walter White não acredita que sua vida possa piorar ainda mais. Quando descobre que tem câncer terminal, Walter decide arriscar tudo para ganhar dinheiro enquanto pode, transformando sua van em um laboratório de metanfetamina.',capa:require('./assets/bb.jpg')}, 
  {titulo:'Suits',lancamento:' 2011', descricao: 'A trama se passa em um escritório de advocacia de Nova York e acompanha o personagem Mike Ross, um jovem talentoso que nunca terminou seus estudos, que começa a trabalhar como advogado associado para Harvey Specter, advogado da Pearson Hadrman muito respeitado em Nova York.',
capa:require('./assets/suits.jpg')},
  {titulo:'The Office',lancamento:' 2005', descricao:' Trata-se de um falso documentário sobre o cotidiano de uma empresa onde os funcionários convivem em uma rotina de absurdos protagonizados pelo gerente regional Michael Scott (Carrell). ',
capa:require('./assets/office.jpg')},
  {titulo:'Game Of Thrones',lancamento:' 2011', descricao:'Game of Thrones retrata o conflito entre 7 reinos das terras de Westeros, uma alusão histórica à Europa Medieval. Basicamente, o conflito se dá entre duas famílias que protagonizam a luta por um trono. No caso, o famoso Trono de Ferro. Aliás, é esse trono que dá origem ao nome da série',capa:require('./assets/got.jpg')}
];